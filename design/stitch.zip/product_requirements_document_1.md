Okay, I understand! Since you haven't provided the "context" yet, I will create a *template* for a Project PRD/Brief.

This template is designed to be comprehensive enough for a full PRD but can be condensed into a brief by focusing on the "Overview," "Problem Statement," "Goals," and "Proposed Solution" sections.

**Please imagine the following template as what I would fill out *after* you provide the specific project context.**

---

# Project PRD / Brief Template: [Project Name - Placeholder]

**Document Version:** 1.0
**Date:** October 26, 2023
**Author(s):** [Your Name/Team]
**Status:** Draft / Review / Approved

---

## 1. Introduction & Overview

### 1.1 Project Title
**[Placeholder: A concise, descriptive title for the project]**
*Example: Enhanced User Onboarding Flow*

### 1.2 Executive Summary
**[Placeholder: A 2-3 paragraph high-level summary of the project. What is it, why are we doing it, and what will it achieve?]**
*Example: This project aims to redesign our current user onboarding experience to reduce churn during the initial setup phase and increase feature adoption. By simplifying the signup process, providing clearer guidance, and personalizing the first-time user experience, we expect to see a significant improvement in user retention and engagement metrics within the first 7 days post-registration.*

### 1.3 Background
**[Placeholder: Briefly describe the context leading up to this project. What existing systems, user feedback, or market trends are informing this initiative?]**
*Example: Our current onboarding flow, developed 3 years ago, has been identified through analytics and user interviews as a major pain point. Data shows a 45% drop-off rate between registration and first successful task completion. Competitor analysis also indicates our onboarding is significantly less intuitive.*

---

## 2. Problem Statement

**[Placeholder: Clearly articulate the problem(s) this project aims to solve. Use specific data or user quotes where possible. Who is experiencing the problem, what is the impact, and why is it important to solve?]**
*Example: "New users struggle to understand the core value proposition and navigate the initial setup steps, leading to a high churn rate (45%) within the first 24 hours of registration. This directly impacts our monthly active users (MAU) growth and customer lifetime value (CLTV). Users often report feeling overwhelmed and confused, leading them to abandon the product before experiencing its benefits."*

---

## 3. Goals & Objectives

**[Placeholder: What specific, measurable, achievable, relevant, and time-bound (SMART) goals will this project accomplish? What does success look like?]**

### 3.1 Business Goals
*   **[Placeholder: Goal 1]** *Example: Increase 7-day user retention by 15% (from 55% to 70%) within 3 months post-launch.*
*   **[Placeholder: Goal 2]** *Example: Reduce customer support tickets related to onboarding by 25% within 2 months post-launch.*
*   **[Placeholder: Goal 3]** *Example: Improve average time-to-value (TTV) for new users by 20% (e.g., from 30 mins to 24 mins) within 1 month post-launch.*

### 3.2 Product Objectives
*   **[Placeholder: Objective 1]** *Example: Create a more intuitive and guided first-time user experience.*
*   **[Placeholder: Objective 2]** *Example: Enable users to successfully complete their first key task within the product with minimal friction.*
*   **[Placeholder: Objective 3]** *Example: Personalize the initial user journey based on stated user goals.*

---

## 4. Target Audience

**[Placeholder: Who are the primary users or stakeholders this project is for? Describe their characteristics, needs, and pain points related to this project.]**
*Example: Our primary target audience is new sign-ups (SMB owners, marketing managers) who are looking for a quick and easy solution to manage their online presence. They are often time-constrained and expect a seamless, self-service setup. A secondary audience includes existing users who might benefit from improved feature discovery through the onboarding flow.*

---

## 5. Proposed Solution / Product Vision

**[Placeholder: Describe the high-level solution or product vision. What are we building, and what is the core experience?]**
*Example: We will develop a multi-step, interactive onboarding wizard that guides users through essential setup tasks. This will include progress indicators, tooltips for complex fields, and dynamic content tailored to their selected industry or role. The flow will culminate in a celebratory "first task complete" screen with immediate next steps to encourage further engagement. We will also introduce a guided tour for key features post-onboarding.*

---

## 6. Features & Functionality (Detailed Requirements)

**[Placeholder: List the specific features and functionalities required. For each, describe its purpose and how it addresses a user need or problem. User stories and acceptance criteria are ideal here.]**

### 6.1 Feature Group 1: [Placeholder: e.g., Simplified Registration]
*   **User Story:** As a new user, I want to sign up quickly using my Google account, so I don't have to fill out many fields.
    *   **Acceptance Criteria:**
        *   User can sign up using Google OAuth.
        *   Existing account check prevents duplicate entries.
        *   Upon successful sign-up, user is directed to the first step of the onboarding wizard.
*   **User Story:** As a new user, I want to see clear error messages if my registration fails, so I can correct the issue and retry.
    *   **Acceptance Criteria:**
        *   Invalid email format displays specific error.
        *   Password requirements are clearly communicated before submission.

### 6.2 Feature Group 2: [Placeholder: e.g., Interactive Onboarding Wizard]
*   **User Story:** As a new user, I want to complete my profile with essential information, so the product can personalize my experience.
    *   **Acceptance Criteria:**
        *   Wizard presents 3-5 mandatory profile fields (e.g., Industry, Role, Company Size).
        *   Progress bar visually tracks completion.
        *   Tooltips are available for complex fields.
*   **User Story:** As a new user, I want to connect a data source (e.g., CRM), so I can immediately see relevant data within the product.
    *   **Acceptance Criteria:**
        *   Wizard includes a step for connecting common integrations.
        *   Clear instructions and links to documentation for each integration.
        *   Success/failure message displayed post-connection attempt.

### 6.3 Feature Group 3: [Placeholder: e.g., Post-Onboarding Engagement]
*   **User Story:** As a new user, I want a quick tour of key features after setup, so I understand where to find important functionalities.
    *   **Acceptance Criteria:**
        *   Optional, dismissible product tour highlights 3 core features.
        *   Tour can be re-launched from settings.

*(Continue adding feature groups and detailed requirements as needed)*

---

## 7. User Experience (UX) & Design

**[Placeholder: Describe the desired user experience, design principles, and any key UI/UX considerations. Link to wireframes, mockups, or prototypes if available.]**
*Example: The new onboarding flow will prioritize simplicity, clarity, and visual appeal. It will follow our existing design system but introduce new animated elements to improve engagement. Key principles include: minimal steps, clear calls to action, immediate feedback, and encouraging progress.
*   **Attached:** Link to Figma prototype: [Link]
*   **Attached:** Link to design system guidelines: [Link]

---

## 8. Technical Considerations & Architecture

**[Placeholder: High-level technical considerations, potential integrations, performance requirements, security, and any architectural decisions or constraints.]**
*Example:
*   **Frontend:** React-based, leveraging existing component library.
*   **Backend:** Node.js microservice for managing user profile and onboarding state.
*   **Database:** PostgreSQL for user data.
*   **Integrations:** Google OAuth, [CRM Integration A] API, [CRM Integration B] API.
*   **Performance:** Each step of the wizard should load within 500ms.
*   **Security:** Ensure all data transfers are encrypted (SSL/TLS). Adhere to GDPR/CCPA for user data.
*   **A/B Testing:** Solution must support A/B testing of different onboarding paths.*

---

## 9. Success Metrics & KPIs

**[Placeholder: How will we measure the success of this project? Link back to the goals.]**
*   **Primary Metrics:**
    *   7-day user retention rate.
    *   Onboarding completion rate (percentage of users completing all steps).
    *   Time to first successful task completion.
*   **Secondary Metrics:**
    *   Number of support tickets related to onboarding.
    *   Feature adoption rate (e.g., percentage of users engaging with X feature in the first 7 days).
    *   NPS score from new users (post-onboarding survey).
*   **Tools:** Google Analytics, Mixpanel, Zendesk.

---

## 10. Non-Goals & Out of Scope

**[Placeholder: Clearly state what this project WILL NOT address or include. This helps manage expectations and focus.]**
*Example:
*   This project will **not** include a complete redesign of the core product dashboard.
*   This project will **not** involve building new CRM integrations beyond the ones specified.
*   This project will **not** focus on re-engaging *lapsed* users; it's purely for new sign-ups.*

---

## 11. Open Questions, Dependencies & Risks

**[Placeholder: What still needs to be determined? What other teams or systems is this project reliant on? What potential risks could impact success?]**

### 11.1 Open Questions
*   **[Placeholder: Question 1]** *Example: What is the exact budget for third-party design resources, if needed?*
*   **[Placeholder: Question 2]** *Example: Which specific CRM integrations are highest priority for MVP?*

### 11.2 Dependencies
*   **[Placeholder: Dependency 1]** *Example: Requires API access to [Third-Party Service] for data import.*
*   **[Placeholder: Dependency 2]** *Example: Relies on Marketing team for new user acquisition strategies to test new flow.*

### 11.3 Risks
*   **[Placeholder: Risk 1]** *Example: Scope creep due to desire for additional integrations, potentially delaying launch.*
    *   **Mitigation:** Strict feature prioritization and "Phase 2" roadmap.
*   **[Placeholder: Risk 2]** *Example: Technical complexity of integrating with legacy systems, leading to unexpected delays.*
    *   **Mitigation:** Early technical spikes and clear communication channels with engineering leadership.*

---

## 12. Future Iterations / Roadmap

**[Placeholder: What comes next? What features or improvements are planned for future phases after the initial launch?]**
*Example:
*   **Phase 2:** Advanced personalization of onboarding based on AI-driven user intent.
*   **Phase 3:** A/B test different tutorial formats (e.g., video vs. interactive walkthroughs).
*   **Phase 4:** Onboarding flow for existing users adopting new major features.*

---

## 13. Appendix & Supporting Documentation

**[Placeholder: Links to any relevant research, competitor analysis, user interview transcripts, existing documentation, etc.]**
*   User Research Summary: [Link]
*   Competitor Onboarding Analysis: [Link]
*   Existing Analytics Dashboard: [Link]

---

**Next Steps:**
Please provide your specific project context, and I will fill out this template for you!